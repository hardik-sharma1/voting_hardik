/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tcs.ignite.Voting.Services;

import com.tcs.ignite.Voting.Beans.UserDetail;
import com.tcs.ignite.Voting.Utils.HibernateUtil;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;

/**
 *
 * @author Hardik
 */
public class UserServices {

    public UserDetail auth(UserDetail ud) {
        Session session = null;
        try {
            session = HibernateUtil.getSessionFactory().openSession();
            session.beginTransaction();
            String hql = "SELECT u FROM UserDetail u WHERE u.userEmail = :userEmail and u.password = :password";
            Query query = session.createQuery(hql);
            query.setParameter("userEmail", ud.getUserEmail());
            query.setParameter("password", ud.getPassword());
            ud = (UserDetail) query.uniqueResult();
            session.getTransaction().commit();
        } catch (Exception ex) {
            session.getTransaction().rollback();
        } finally {
            session.close();
        }
        return ud;
    }

    public boolean register(UserDetail ud) 
    {
        Session session = null;
        boolean isregister = false;
        try {
           session = (Session) HibernateUtil.getSessionFactory().openSession();
            session.beginTransaction();
            session.save(ud);
            session.getTransaction().commit();
            isregister = true;
            
        } catch (HibernateException ex) {
            session.getTransaction().rollback();
            isregister = false;

        } finally {
            session.close();
        }
        
        if (isregister) {
//            object.put("responseCode", 1);
            return isregister;
        } else {
//            object.put("responseCode", 0);
            return isregister;
        }
    }


}
