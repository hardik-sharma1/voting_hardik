/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tcs.ignite.Voting.Beans;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Hardik
 */
@Entity
@Table(name = "master_roll")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "MasterRoll.findAll", query = "SELECT m FROM MasterRoll m")
    , @NamedQuery(name = "MasterRoll.findByRollId", query = "SELECT m FROM MasterRoll m WHERE m.rollId = :rollId")
    , @NamedQuery(name = "MasterRoll.findByRollName", query = "SELECT m FROM MasterRoll m WHERE m.rollName = :rollName")})
public class MasterRoll implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "roll_id")
    private Integer rollId;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "roll_name")
    private String rollName;

    public MasterRoll() {
    }

    public MasterRoll(Integer rollId) {
        this.rollId = rollId;
    }

    public MasterRoll(Integer rollId, String rollName) {
        this.rollId = rollId;
        this.rollName = rollName;
    }

    public Integer getRollId() {
        return rollId;
    }

    public void setRollId(Integer rollId) {
        this.rollId = rollId;
    }

    public String getRollName() {
        return rollName;
    }

    public void setRollName(String rollName) {
        this.rollName = rollName;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (rollId != null ? rollId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof MasterRoll)) {
            return false;
        }
        MasterRoll other = (MasterRoll) object;
        if ((this.rollId == null && other.rollId != null) || (this.rollId != null && !this.rollId.equals(other.rollId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.tcs.ignite.Voting.Beans.MasterRoll[ rollId=" + rollId + " ]";
    }
    
}
