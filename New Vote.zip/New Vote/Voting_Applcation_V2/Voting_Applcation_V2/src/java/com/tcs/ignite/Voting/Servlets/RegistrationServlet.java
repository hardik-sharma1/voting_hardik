/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tcs.ignite.Voting.Servlets;

import com.tcs.ignite.Voting.Beans.UserDetail;
import com.tcs.ignite.Voting.Services.UserServices;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Hardik
 */
public class RegistrationServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
                PrintWriter out = response.getWriter();
        String name = request.getParameter("user_name");
        String email = request.getParameter("email");
        String phone = request.getParameter("phone");
        String dob = request.getParameter("dob");
        String password = request.getParameter("password");
        UserDetail ud = new UserDetail();
        ud.setDob(dob);
        ud.setPassword(password);
        ud.setPhone(phone);
        ud.setUserEmail(email);
        ud.setUserName(name);
        UserServices  us = new UserServices();
        boolean isregister = us.register(ud);
        if(isregister==true)
        {
            out.print("true");
        }
        else
        {
            out.print("false");
        }
    
    }
}
