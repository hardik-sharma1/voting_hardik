/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tcs.ignite.Voting.Servlets;

import com.tcs.ignite.Voting.Beans.UserDetail;
import com.tcs.ignite.Voting.Services.UserServices;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.json.simple.JSONObject;

/**
 *
 * @author Hardik
 */
public class LoginServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        PrintWriter out = response.getWriter();
        UserDetail ud = new UserDetail();
        ud.setUserEmail(request.getParameter("user_name"));
        ud.setPassword(request.getParameter("password"));
        UserServices ls = new UserServices();
        JSONObject object = new JSONObject();
        ud = ls.auth(ud);
        if (ud != null) {
            object.put("user_id", ud.getId());
            object.put("name", ud.getUserName());
            object.put("email", ud.getUserEmail());
            object.put("phone", ud.getPhone());
            object.put("rollId", ud.getRollId());
            object.put("responseCode", 1);
            HttpSession httpsession = request.getSession();
            httpsession.setAttribute("User_Id", ud.getId());
            httpsession.setAttribute("name", ud.getUserName());
            httpsession.setAttribute("Role_Id", ud.getRollId());
        }
        if (object.size() != 0) {
            out.print(object);
        } else {
            object.put("responseCode", 0);
            out.print(object);
        }

    }

}
