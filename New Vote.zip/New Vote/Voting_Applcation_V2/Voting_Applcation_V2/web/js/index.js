
$("document").ready(function ()
{
    $("#btn").click(function ()
    {
        $.ajax(
                {
                    url: "RegistrationServlet",
                    method: "Post",
                    data: {
                        user_name: $("#user_name").val(),
                        password: $("#password").val(),
                        email: $("#email").val(),
                        phone: $("#phone").val(),
                        dob: $("#dob").val()
                    },
                    success: function (data)
                    {
                        window.location.href = "Login.jsp";
                        alert("register successfully");
                    },
                    error: function (data)
                    {
                        window.location.href = "Login.jsp";
                    }
                });
    });
});
